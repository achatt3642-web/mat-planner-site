"""Knee MRI planning prototype package."""

