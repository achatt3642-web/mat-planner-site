from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np


def simple_otsu_knee_bone_segment(image: Any, model_spec: Any, work_dir: Path) -> Any:
    """Fallback knee-bone segmentation (prototype only).

    This is intentionally simple and should not be used clinically.
    It provides immediate runnable behavior when a production segmenter
    is not configured yet.
    """
    try:
        import SimpleITK as sitk
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("SimpleITK is required for fallback segmentation") from exc

    arr = sitk.GetArrayFromImage(image).astype(np.float32)  # z, y, x
    if arr.size == 0:
        raise RuntimeError("Empty volume")

    # Robust normalize and threshold.
    p1, p99 = np.percentile(arr, [1.0, 99.0])
    if p99 <= p1:
        p1 = float(arr.min())
        p99 = float(arr.max()) + 1e-6
    norm = np.clip((arr - p1) / (p99 - p1), 0.0, 1.0)
    mask = norm > np.quantile(norm, 0.72)

    # Keep connected tissue and split by superior/inferior location.
    comp = sitk.ConnectedComponent(sitk.GetImageFromArray(mask.astype(np.uint8)))
    comp = sitk.RelabelComponent(comp, sortByObjectSize=True)
    comp_arr = sitk.GetArrayFromImage(comp)
    largest = comp_arr == 1
    if largest.sum() < 500:
        largest = mask

    coords = np.argwhere(largest)
    z_med = int(np.median(coords[:, 0])) if coords.size else arr.shape[0] // 2
    femur = largest & (np.indices(arr.shape)[0] <= z_med)
    tibia = largest & (np.indices(arr.shape)[0] > z_med)

    # Fill and clean.
    fem_itk = sitk.BinaryFillhole(sitk.GetImageFromArray(femur.astype(np.uint8)))
    tib_itk = sitk.BinaryFillhole(sitk.GetImageFromArray(tibia.astype(np.uint8)))
    fem_itk = sitk.BinaryMorphologicalClosing(fem_itk, [2, 2, 2])
    tib_itk = sitk.BinaryMorphologicalClosing(tib_itk, [2, 2, 2])

    fem_arr = sitk.GetArrayFromImage(fem_itk).astype(np.uint8)
    tib_arr = sitk.GetArrayFromImage(tib_itk).astype(np.uint8)

    out = np.zeros_like(fem_arr, dtype=np.uint8)
    out[fem_arr > 0] = 1
    out[tib_arr > 0] = 2
    out_itk = sitk.GetImageFromArray(out)
    out_itk.CopyInformation(image)
    return out_itk

