from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple


STANDARD_LABELS = {"femur": 1, "tibia": 2}


@dataclass
class SeriesFingerprint:
    source_path: Path
    source_kind: str  # dicom_series | nifti
    series_id: Optional[str] = None
    num_files: int = 1
    modality: Optional[str] = "MR"
    manufacturer: Optional[str] = None
    manufacturer_model_name: Optional[str] = None
    magnetic_field_strength_t: Optional[float] = None
    series_description: Optional[str] = None
    sequence_name: Optional[str] = None
    protocol_name: Optional[str] = None
    scanning_sequence: Optional[str] = None
    image_type: Optional[str] = None
    orientation: Optional[str] = None  # SAGITTAL | CORONAL | AXIAL | UNKNOWN
    size: Optional[Tuple[int, int, int]] = None
    spacing: Optional[Tuple[float, float, float]] = None
    axes_code: Optional[str] = None
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class LoadedVolume:
    image: Any  # SimpleITK.Image at runtime
    fingerprint: SeriesFingerprint
    source_files: List[Path] = field(default_factory=list)


@dataclass
class ModelSpec:
    id: str
    backend: str
    priority: int = 0
    description: str = ""
    model_path: Optional[str] = None
    use_folds: Sequence[int] = field(default_factory=lambda: (0,))
    checkpoint_name: str = "checkpoint_final.pth"
    series_description_regex: Optional[str] = None
    sequence_name_regex: Optional[str] = None
    protocol_name_regex: Optional[str] = None
    orientations: Sequence[str] = field(default_factory=tuple)
    modalities: Sequence[str] = field(default_factory=lambda: ("MR",))
    min_inplane_size: Optional[int] = None
    max_slice_thickness_mm: Optional[float] = None
    label_map: Dict[int, str] = field(default_factory=dict)
    backend_kwargs: Dict[str, Any] = field(default_factory=dict)
    raw: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AttemptResult:
    candidate_series: SeriesFingerprint
    model_spec: ModelSpec
    passed_qc: bool
    qc_score: float
    output_mask_path: Optional[Path]
    report: Dict[str, Any]
    error: Optional[str] = None


@dataclass
class PipelineResult:
    success: bool
    selected_series: Optional[SeriesFingerprint]
    selected_model: Optional[ModelSpec]
    output_mask_path: Optional[Path]
    attempts: List[AttemptResult] = field(default_factory=list)
    report_path: Optional[Path] = None
