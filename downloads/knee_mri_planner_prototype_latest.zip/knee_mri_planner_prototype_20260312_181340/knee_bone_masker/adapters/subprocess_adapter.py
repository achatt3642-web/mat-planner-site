from __future__ import annotations

import shlex
import subprocess
from pathlib import Path
from typing import Any

from .base import SegmenterBackend
from ..types import ModelSpec


class SubprocessAdapter(SegmenterBackend):
    """Run any external segmentation command.

    Registry example:
      backend_kwargs:
        command_template: my_seg_tool --input {input} --output {output}
    """

    def predict(self, image: Any, model_spec: ModelSpec, work_dir: Path) -> Any:
        try:
            import SimpleITK as sitk
        except ImportError as exc:
            raise RuntimeError("SimpleITK is required for the subprocess backend.") from exc

        kwargs = dict(model_spec.backend_kwargs or {})
        template = kwargs.get("command_template")
        if not template:
            raise ValueError(f"Model {model_spec.id} is missing backend_kwargs.command_template")

        input_path = work_dir / "subprocess_input.nii.gz"
        output_path = work_dir / "subprocess_output.nii.gz"
        sitk.WriteImage(image, str(input_path), useCompression=True)

        cmd = template.format(input=str(input_path), output=str(output_path))
        proc = subprocess.run(
            shlex.split(cmd),
            cwd=str(work_dir),
            check=False,
            capture_output=True,
            text=True,
        )
        if proc.returncode != 0:
            raise RuntimeError(
                f"External command failed with code {proc.returncode}\n"
                f"STDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}"
            )
        if not output_path.exists():
            raise RuntimeError(f"External command finished but did not create {output_path}")
        return sitk.ReadImage(str(output_path))
