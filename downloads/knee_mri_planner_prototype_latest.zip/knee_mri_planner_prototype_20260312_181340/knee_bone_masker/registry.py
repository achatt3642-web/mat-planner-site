from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List

import yaml

from .types import ModelSpec, SeriesFingerprint


class RegistryError(RuntimeError):
    pass


def _coerce_label_map(label_map: Dict[Any, Any]) -> Dict[int, str]:
    coerced: Dict[int, str] = {}
    for key, value in (label_map or {}).items():
        coerced[int(key)] = str(value).strip().lower()
    return coerced


def load_model_registry(path: str | Path) -> List[ModelSpec]:
    path = Path(path)
    if not path.exists():
        raise RegistryError(f"Registry file not found: {path}")

    if path.suffix.lower() in {".yaml", ".yml"}:
        data = yaml.safe_load(path.read_text())
    elif path.suffix.lower() == ".json":
        data = json.loads(path.read_text())
    else:
        raise RegistryError("Registry must be YAML or JSON.")

    if not isinstance(data, list):
        raise RegistryError("Registry root must be a list of model specifications.")

    specs: List[ModelSpec] = []
    for item in data:
        if not isinstance(item, dict):
            raise RegistryError("Each registry entry must be a mapping.")
        spec = ModelSpec(
            id=item["id"],
            backend=item["backend"],
            priority=int(item.get("priority", 0)),
            description=str(item.get("description", "")),
            model_path=item.get("model_path"),
            use_folds=tuple(item.get("use_folds", (0,))),
            checkpoint_name=str(item.get("checkpoint_name", "checkpoint_final.pth")),
            series_description_regex=item.get("series_description_regex"),
            sequence_name_regex=item.get("sequence_name_regex"),
            protocol_name_regex=item.get("protocol_name_regex"),
            orientations=tuple(str(v).upper() for v in item.get("orientations", ()) if v is not None),
            modalities=tuple(str(v).upper() for v in item.get("modalities", ("MR",)) if v is not None),
            min_inplane_size=item.get("min_inplane_size"),
            max_slice_thickness_mm=item.get("max_slice_thickness_mm"),
            label_map=_coerce_label_map(item.get("label_map", {})),
            backend_kwargs=dict(item.get("backend_kwargs", {})),
            raw=dict(item),
        )
        specs.append(spec)

    return specs


def _regex_match(pattern: str | None, text: str | None) -> bool:
    if not pattern:
        return True
    if not text:
        return False
    return re.search(pattern, text) is not None


def score_model_for_series(spec: ModelSpec, fp: SeriesFingerprint) -> float:
    """Heuristic compatibility score for routing.

    Higher is better. Very negative means "do not use".
    """
    score = float(spec.priority)

    modality = (fp.modality or "").upper()
    if spec.modalities and modality and modality not in spec.modalities:
        return -1e9

    if not _regex_match(spec.series_description_regex, fp.series_description):
        score -= 30.0
    else:
        score += 20.0

    if not _regex_match(spec.sequence_name_regex, fp.sequence_name):
        score -= 20.0
    else:
        score += 15.0

    if not _regex_match(spec.protocol_name_regex, fp.protocol_name):
        score -= 10.0
    else:
        score += 10.0

    if spec.orientations:
        if (fp.orientation or "UNKNOWN").upper() in spec.orientations:
            score += 20.0
        else:
            score -= 20.0

    if fp.size and spec.min_inplane_size:
        if min(fp.size[0], fp.size[1]) >= spec.min_inplane_size:
            score += 5.0
        else:
            score -= 15.0

    if fp.spacing and spec.max_slice_thickness_mm is not None:
        if max(fp.spacing) <= float(spec.max_slice_thickness_mm):
            score += 5.0
        else:
            score -= 15.0

    # Mild preference for near-isotropic volumes.
    if fp.spacing:
        mn = min(fp.spacing)
        mx = max(fp.spacing)
        if mn > 0 and mx / mn <= 2.5:
            score += 3.0

    return score


def rank_models(specs: Iterable[ModelSpec], fp: SeriesFingerprint) -> List[ModelSpec]:
    return sorted(specs, key=lambda s: score_model_for_series(s, fp), reverse=True)
