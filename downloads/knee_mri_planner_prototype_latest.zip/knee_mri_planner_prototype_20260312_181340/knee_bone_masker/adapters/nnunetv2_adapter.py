from __future__ import annotations

from pathlib import Path
from typing import Any

from .base import SegmenterBackend
from ..types import ModelSpec


class NnUNetV2Adapter(SegmenterBackend):
    """Run inference using nnU-Net v2 Python APIs.

    This follows the official pattern built around `nnUNetPredictor` and
    `initialize_from_trained_model_folder(...)`.
    """

    def predict(self, image: Any, model_spec: ModelSpec, work_dir: Path) -> Any:
        try:
            import SimpleITK as sitk
            import torch
            from nnunetv2.inference.predict_from_raw_data import nnUNetPredictor
        except ImportError as exc:
            raise RuntimeError(
                "nnU-Net v2 backend requested but required packages are not installed."
            ) from exc

        if not model_spec.model_path:
            raise ValueError(f"Model {model_spec.id} is missing model_path.")

        input_dir = work_dir / "nnunet_input"
        output_dir = work_dir / "nnunet_output"
        input_dir.mkdir(parents=True, exist_ok=True)
        output_dir.mkdir(parents=True, exist_ok=True)

        case_path = input_dir / "case_0000.nii.gz"
        sitk.WriteImage(image, str(case_path), useCompression=True)

        kwargs = dict(model_spec.backend_kwargs or {})
        tile_step_size = float(kwargs.get("tile_step_size", 0.5))
        use_gaussian = bool(kwargs.get("use_gaussian", True))
        use_mirroring = bool(kwargs.get("use_mirroring", True))
        perform_everything_on_device = bool(kwargs.get("perform_everything_on_device", True))
        num_proc_pre = int(kwargs.get("num_processes_preprocessing", 2))
        num_proc_exp = int(kwargs.get("num_processes_segmentation_export", 2))
        verbose = bool(kwargs.get("verbose", False))
        verbose_preprocessing = bool(kwargs.get("verbose_preprocessing", False))
        allow_tqdm = bool(kwargs.get("allow_tqdm", False))

        device = torch.device("cuda", 0) if torch.cuda.is_available() else torch.device("cpu")
        predictor = nnUNetPredictor(
            tile_step_size=tile_step_size,
            use_gaussian=use_gaussian,
            use_mirroring=use_mirroring,
            perform_everything_on_device=perform_everything_on_device and torch.cuda.is_available(),
            device=device,
            verbose=verbose,
            verbose_preprocessing=verbose_preprocessing,
            allow_tqdm=allow_tqdm,
        )
        predictor.initialize_from_trained_model_folder(
            model_spec.model_path,
            use_folds=tuple(model_spec.use_folds),
            checkpoint_name=model_spec.checkpoint_name,
        )

        out_path = output_dir / "case.nii.gz"
        predictor.predict_from_files(
            [[str(case_path)]],
            [str(out_path)],
            save_probabilities=False,
            overwrite=True,
            num_processes_preprocessing=num_proc_pre,
            num_processes_segmentation_export=num_proc_exp,
            folder_with_segs_from_prev_stage=None,
            num_parts=1,
            part_id=0,
        )
        return sitk.ReadImage(str(out_path))
