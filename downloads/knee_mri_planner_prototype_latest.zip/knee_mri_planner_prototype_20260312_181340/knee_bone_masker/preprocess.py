from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional


def _require_sitk():
    import SimpleITK as sitk
    return sitk


@dataclass
class PreprocessTrace:
    original_axes_code: Optional[str]
    working_axes_code: Optional[str]
    reoriented: bool


def maybe_reorient_to(image: Any, target_axes_code: str | None) -> tuple[Any, PreprocessTrace]:
    sitk = _require_sitk()
    original = sitk.DICOMOrientImageFilter_GetOrientationFromDirectionCosines(image.GetDirection())
    if not target_axes_code or target_axes_code.upper() == original.upper():
        return image, PreprocessTrace(original_axes_code=original, working_axes_code=original, reoriented=False)
    transformed = sitk.DICOMOrient(image, target_axes_code.upper())
    return transformed, PreprocessTrace(original_axes_code=original, working_axes_code=target_axes_code.upper(), reoriented=True)


def restore_orientation(mask: Any, trace: PreprocessTrace) -> Any:
    sitk = _require_sitk()
    if not trace.reoriented or not trace.original_axes_code:
        return mask
    return sitk.DICOMOrient(mask, trace.original_axes_code)
