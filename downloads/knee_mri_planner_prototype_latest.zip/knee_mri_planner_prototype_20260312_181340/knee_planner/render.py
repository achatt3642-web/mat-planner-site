from __future__ import annotations

from pathlib import Path
from typing import Any

import nibabel as nib
import numpy as np
import plotly.graph_objects as go
from skimage.measure import marching_cubes


def _mask_mesh(mask: np.ndarray, spacing_zyx: tuple[float, float, float]) -> tuple[np.ndarray, np.ndarray] | None:
    if mask.sum() < 50:
        return None
    verts, faces, _, _ = marching_cubes(mask.astype(np.float32), level=0.5)
    # marching cubes returns z,y,x. We map to plotting axes:
    # x = ML, y = SI, z = AP (per requested convention).
    sz, sy, sx = spacing_zyx
    x = verts[:, 2] * sx
    y = verts[:, 1] * sy
    z = verts[:, 0] * sz
    return np.stack([x, y, z], axis=1), faces


def _ellipse_points(center_xyz: tuple[float, float, float], length_mm: float, width_mm: float, n: int = 120) -> np.ndarray:
    cx, cy, cz = center_xyz
    t = np.linspace(0.0, 2.0 * np.pi, n)
    # AP ~ z axis (length), ML ~ x axis (width), SI ~ y axis
    x = cx + 0.5 * width_mm * np.cos(t)
    y = np.full_like(x, cy)
    z = cz + 0.5 * length_mm * np.sin(t)
    return np.stack([x, y, z], axis=1)


def create_knee_scene(
    seg_path: Path,
    predictions: dict[str, float],
    horns: dict[str, Any],
    title: str = "Knee 3D Planning View",
) -> go.Figure:
    img = nib.load(str(seg_path))
    arr = np.asarray(img.get_fdata(), dtype=np.uint8)
    fem = (arr == 1) | (arr == 7)
    tib = (arr == 2) | (arr == 8)
    spacing = tuple(float(v) for v in img.header.get_zooms()[:3])

    fig = go.Figure()
    fem_mesh = _mask_mesh(fem, spacing)
    tib_mesh = _mask_mesh(tib, spacing)
    if fem_mesh is not None:
        verts, faces = fem_mesh
        fig.add_trace(
            go.Mesh3d(
                x=verts[:, 0],
                y=verts[:, 1],
                z=verts[:, 2],
                i=faces[:, 0],
                j=faces[:, 1],
                k=faces[:, 2],
                color="#1f77b4",
                opacity=0.38,
                flatshading=True,
                lighting={"ambient": 0.55, "diffuse": 0.75, "specular": 0.1},
                name="Femur bone",
                showlegend=True,
            )
        )
    if tib_mesh is not None:
        verts, faces = tib_mesh
        fig.add_trace(
            go.Mesh3d(
                x=verts[:, 0],
                y=verts[:, 1],
                z=verts[:, 2],
                i=faces[:, 0],
                j=faces[:, 1],
                k=faces[:, 2],
                color="#2ca02c",
                opacity=0.38,
                flatshading=True,
                lighting={"ambient": 0.55, "diffuse": 0.75, "specular": 0.1},
                name="Tibia bone",
                showlegend=True,
            )
        )

    # Meniscus allograft overlay as compartment ellipses at plateau level.
    # Convention: axis0=z->AP, axis1=y->SI, axis2=x->ML.
    tib_coords = np.argwhere(tib)
    if tib_coords.size > 0:
        y_si = np.percentile(tib_coords[:, 1], 20.0) * spacing[1]
        x_mid = np.median(tib_coords[:, 2]) * spacing[2]
        z_ap = np.median(tib_coords[:, 0]) * spacing[0]
        med_center = (x_mid + 12.0, y_si, z_ap)
        lat_center = (x_mid - 12.0, y_si, z_ap)

        # If horn points are available, anchor allograft center to horn midpoint
        # so curves and landmarks are geometrically coherent.
        med_h = horns.get("medial")
        if med_h is not None:
            ant = np.asarray(med_h.anterior_xyz_mm, dtype=float)
            post = np.asarray(med_h.posterior_xyz_mm, dtype=float)
            med_center = tuple(((ant + post) * 0.5).tolist())
        lat_h = horns.get("lateral")
        if lat_h is not None:
            ant = np.asarray(lat_h.anterior_xyz_mm, dtype=float)
            post = np.asarray(lat_h.posterior_xyz_mm, dtype=float)
            lat_center = tuple(((ant + post) * 0.5).tolist())

        med_pts = _ellipse_points(
            med_center,
            float(predictions.get("medial_length_mm", 40.0)),
            float(predictions.get("medial_width_mm", 28.0)),
        )
        lat_pts = _ellipse_points(
            lat_center,
            float(predictions.get("lateral_length_mm", 34.0)),
            float(predictions.get("lateral_width_mm", 32.0)),
        )

        fig.add_trace(
            go.Scatter3d(
                x=med_pts[:, 0],
                y=med_pts[:, 1],
                z=med_pts[:, 2],
                mode="lines",
                line={"color": "#ff7f0e", "width": 8},
                name="Medial allograft",
            )
        )
        fig.add_trace(
            go.Scatter3d(
                x=lat_pts[:, 0],
                y=lat_pts[:, 1],
                z=lat_pts[:, 2],
                mode="lines",
                line={"color": "#d62728", "width": 8},
                name="Lateral allograft",
            )
        )

    # Horn markers.
    for comp, color in [("medial", "#ff7f0e"), ("lateral", "#d62728")]:
        h = horns.get(comp)
        if h is None:
            continue
        ant = np.asarray(h.anterior_xyz_mm, dtype=float)
        post = np.asarray(h.posterior_xyz_mm, dtype=float)
        fig.add_trace(
            go.Scatter3d(
                x=[ant[0], post[0]],
                y=[ant[1], post[1]],
                z=[ant[2], post[2]],
                mode="markers+text",
                marker={"size": 5, "color": color},
                text=[f"{comp[:3]} ANT", f"{comp[:3]} POST"],
                textposition="top center",
                name=f"{comp.capitalize()} horn landmarks",
            )
        )

    fig.update_layout(
        title=title,
        scene=dict(
            xaxis_title="ML (mm)",
            yaxis_title="SI (mm)",
            zaxis_title="AP (mm)",
            aspectmode="data",
            camera={"eye": {"x": 1.55, "y": 1.45, "z": 1.25}},
        ),
        template="plotly_white",
        legend={"orientation": "h"},
    )
    return fig
