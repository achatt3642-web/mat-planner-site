from __future__ import annotations

import traceback
from pathlib import Path
from typing import Any, Dict, List

from .adapters import get_backend
from .io_utils import discover_input_candidates, write_image, write_json
from .postprocess import fill_holes_per_label, keep_largest_component_per_label, split_binary_masks, standardize_labels
from .preprocess import maybe_reorient_to, restore_orientation
from .qc import run_basic_qc
from .registry import load_model_registry
from .router import build_route_plan
from .types import AttemptResult, PipelineResult, SeriesFingerprint


class BoneMaskPipeline:
    def __init__(self, registry_path: str | Path, work_root: str | Path | None = None):
        self.registry_path = Path(registry_path)
        self.specs = load_model_registry(self.registry_path)
        self.work_root = Path(work_root) if work_root is not None else None

    def segment(self, input_path: str | Path, outdir: str | Path, continue_after_success: bool = False) -> PipelineResult:
        outdir = Path(outdir)
        outdir.mkdir(parents=True, exist_ok=True)
        volumes = discover_input_candidates(input_path)
        route_plan = build_route_plan(volumes, self.specs)

        attempts: List[AttemptResult] = []
        selected_series = None
        selected_model = None
        final_mask_path = None

        for idx, choice in enumerate(route_plan):
            attempt_dir = outdir / f"attempt_{idx:02d}_{choice.model_spec.id}"
            attempt_dir.mkdir(parents=True, exist_ok=True)
            try:
                # Most segmentation models are happiest with a stable orientation.
                target_axes = str(choice.model_spec.backend_kwargs.get("canonical_axes", "LPS"))
                working_image, trace = maybe_reorient_to(choice.volume.image, target_axes)

                backend = get_backend(choice.model_spec.backend)
                raw_mask = backend.predict(working_image, choice.model_spec, attempt_dir)
                raw_mask = restore_orientation(raw_mask, trace)
                standardized = standardize_labels(raw_mask, choice.model_spec.label_map)
                standardized = keep_largest_component_per_label(standardized)
                standardized = fill_holes_per_label(standardized)

                qc = run_basic_qc(
                    standardized,
                    fingerprint={
                        "spacing": choice.volume.fingerprint.spacing,
                        "size": choice.volume.fingerprint.size,
                        "orientation": choice.volume.fingerprint.orientation,
                    },
                )

                mask_path = attempt_dir / "bone_mask.nii.gz"
                write_image(standardized, mask_path)
                binaries = split_binary_masks(standardized)
                write_image(binaries["femur"], attempt_dir / "femur_mask.nii.gz")
                write_image(binaries["tibia"], attempt_dir / "tibia_mask.nii.gz")

                report = {
                    "route_score": choice.score,
                    "model_id": choice.model_spec.id,
                    "backend": choice.model_spec.backend,
                    "series_fingerprint": _fingerprint_to_dict(choice.volume.fingerprint),
                    "qc": qc.to_dict(),
                }
                write_json(report, attempt_dir / "attempt_report.json")
                attempts.append(
                    AttemptResult(
                        candidate_series=choice.volume.fingerprint,
                        model_spec=choice.model_spec,
                        passed_qc=qc.passed,
                        qc_score=qc.score,
                        output_mask_path=mask_path,
                        report=report,
                    )
                )

                if qc.passed and final_mask_path is None:
                    final_mask_path = outdir / "bone_mask.nii.gz"
                    write_image(standardized, final_mask_path)
                    write_image(binaries["femur"], outdir / "femur_mask.nii.gz")
                    write_image(binaries["tibia"], outdir / "tibia_mask.nii.gz")
                    selected_series = choice.volume.fingerprint
                    selected_model = choice.model_spec
                    if not continue_after_success:
                        break
            except Exception as exc:
                tb = traceback.format_exc()
                error_report = {
                    "route_score": choice.score,
                    "model_id": choice.model_spec.id,
                    "backend": choice.model_spec.backend,
                    "series_fingerprint": _fingerprint_to_dict(choice.volume.fingerprint),
                    "error": str(exc),
                    "traceback": tb,
                }
                write_json(error_report, attempt_dir / "attempt_error.json")
                attempts.append(
                    AttemptResult(
                        candidate_series=choice.volume.fingerprint,
                        model_spec=choice.model_spec,
                        passed_qc=False,
                        qc_score=0.0,
                        output_mask_path=None,
                        report=error_report,
                        error=str(exc),
                    )
                )

        summary = {
            "success": final_mask_path is not None,
            "selected_series": _fingerprint_to_dict(selected_series) if selected_series else None,
            "selected_model": _model_to_dict(selected_model) if selected_model else None,
            "attempt_count": len(attempts),
            "attempts": [
                {
                    "model_id": a.model_spec.id,
                    "series_description": a.candidate_series.series_description,
                    "series_orientation": a.candidate_series.orientation,
                    "passed_qc": a.passed_qc,
                    "qc_score": a.qc_score,
                    "output_mask_path": str(a.output_mask_path) if a.output_mask_path else None,
                    "error": a.error,
                }
                for a in attempts
            ],
        }
        report_path = outdir / "run_report.json"
        attempts_path = outdir / "attempts.json"
        write_json(summary, report_path)
        write_json({"attempts": [a.report for a in attempts]}, attempts_path)

        return PipelineResult(
            success=final_mask_path is not None,
            selected_series=selected_series,
            selected_model=selected_model,
            output_mask_path=final_mask_path,
            attempts=attempts,
            report_path=report_path,
        )


def _fingerprint_to_dict(fp: SeriesFingerprint | None) -> Dict[str, Any] | None:
    if fp is None:
        return None
    return {
        "source_path": str(fp.source_path),
        "source_kind": fp.source_kind,
        "series_id": fp.series_id,
        "num_files": fp.num_files,
        "modality": fp.modality,
        "manufacturer": fp.manufacturer,
        "manufacturer_model_name": fp.manufacturer_model_name,
        "magnetic_field_strength_t": fp.magnetic_field_strength_t,
        "series_description": fp.series_description,
        "sequence_name": fp.sequence_name,
        "protocol_name": fp.protocol_name,
        "scanning_sequence": fp.scanning_sequence,
        "image_type": fp.image_type,
        "orientation": fp.orientation,
        "size": list(fp.size) if fp.size else None,
        "spacing": list(fp.spacing) if fp.spacing else None,
        "axes_code": fp.axes_code,
        "extra": fp.extra,
    }


def _model_to_dict(model) -> Dict[str, Any] | None:
    if model is None:
        return None
    return {
        "id": model.id,
        "backend": model.backend,
        "priority": model.priority,
        "description": model.description,
        "model_path": model.model_path,
    }
