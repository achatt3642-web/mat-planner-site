from __future__ import annotations

import argparse
from pathlib import Path

from .pipeline import BoneMaskPipeline


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Segment femur and tibia from a knee MRI study or volume using a routed model zoo."
    )
    parser.add_argument("input_path", help="DICOM folder or NIfTI file")
    parser.add_argument("--registry", required=True, help="YAML/JSON model registry")
    parser.add_argument("--outdir", required=True, help="Output directory")
    parser.add_argument(
        "--continue-after-success",
        action="store_true",
        help="Keep evaluating lower-ranked routes even after the first QC-passing result.",
    )
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    pipeline = BoneMaskPipeline(registry_path=args.registry)
    result = pipeline.segment(
        input_path=args.input_path,
        outdir=args.outdir,
        continue_after_success=args.continue_after_success,
    )
    if result.success:
        print(f"SUCCESS: {result.output_mask_path}")
        print(f"Selected model: {result.selected_model.id if result.selected_model else 'unknown'}")
        print(f"Report: {result.report_path}")
    else:
        print("FAILED: no route produced a QC-passing mask")
        print(f"Report: {result.report_path}")
        raise SystemExit(2)


if __name__ == "__main__":
    main()
