from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Dict, List


def _require_sitk():
    import SimpleITK as sitk
    return sitk


@dataclass
class LabelQC:
    label: int
    name: str
    voxel_count: int
    volume_mm3: float
    num_components: int
    largest_component_ratio: float
    bbox: tuple[int, int, int, int, int, int] | None


@dataclass
class QCSummary:
    passed: bool
    score: float
    reasons: List[str]
    warnings: List[str]
    by_label: Dict[str, Dict[str, object]]

    def to_dict(self) -> Dict[str, object]:
        return {
            "passed": self.passed,
            "score": self.score,
            "reasons": list(self.reasons),
            "warnings": list(self.warnings),
            "by_label": self.by_label,
        }


STANDARD = {1: "femur", 2: "tibia"}


def _component_stats(binary: Any) -> tuple[int, float]:
    sitk = _require_sitk()
    cc = sitk.ConnectedComponent(binary)
    stats = sitk.LabelShapeStatisticsImageFilter()
    stats.Execute(cc)
    labels = list(stats.GetLabels())
    if not labels:
        return 0, 0.0
    sizes = [stats.GetNumberOfPixels(lbl) for lbl in labels]
    total = float(sum(sizes))
    largest = float(max(sizes))
    ratio = (largest / total) if total > 0 else 0.0
    return len(labels), ratio


def run_basic_qc(mask: Any, fingerprint: Dict[str, object] | None = None) -> QCSummary:
    sitk = _require_sitk()
    spacing = tuple(float(v) for v in mask.GetSpacing())
    voxel_volume = spacing[0] * spacing[1] * spacing[2]

    reasons: List[str] = []
    warnings: List[str] = []
    by_label: Dict[str, Dict[str, object]] = {}
    score = 100.0

    for label, name in STANDARD.items():
        binary = sitk.Cast(mask == label, sitk.sitkUInt8)
        stats = sitk.LabelShapeStatisticsImageFilter()
        stats.Execute(binary)
        voxel_count = int(stats.GetNumberOfPixels(1)) if stats.HasLabel(1) else 0
        volume_mm3 = voxel_count * voxel_volume
        num_components, largest_ratio = _component_stats(binary)
        bbox = tuple(int(v) for v in stats.GetBoundingBox(1)) if stats.HasLabel(1) else None
        by_label[name] = LabelQC(
            label=label,
            name=name,
            voxel_count=voxel_count,
            volume_mm3=volume_mm3,
            num_components=num_components,
            largest_component_ratio=largest_ratio,
            bbox=bbox,
        ).__dict__

        if voxel_count == 0:
            reasons.append(f"missing_{name}")
            score -= 60.0
        if voxel_count < 500:
            reasons.append(f"{name}_too_small")
            score -= 20.0
        if volume_mm3 > 2_500_000:
            reasons.append(f"{name}_too_large")
            score -= 20.0
        if num_components > 3:
            warnings.append(f"{name}_fragmented")
            score -= 8.0
        if 0 < largest_ratio < 0.85:
            warnings.append(f"{name}_large_component_ratio_low")
            score -= 8.0

    # Coarse image warnings only.
    if fingerprint and isinstance(fingerprint, dict):
        spacing_in = fingerprint.get("spacing")
        if isinstance(spacing_in, (list, tuple)) and len(spacing_in) == 3:
            try:
                mx = max(float(v) for v in spacing_in)
                mn = min(float(v) for v in spacing_in)
                if mx > 2.5:
                    warnings.append("coarse_spacing")
                    score -= 5.0
                if mn > 0 and mx / mn > 5.0:
                    warnings.append("high_anisotropy")
                    score -= 5.0
            except Exception:
                pass

    passed = (len([r for r in reasons if r.startswith("missing_")]) == 0) and score >= 60.0
    return QCSummary(passed=passed, score=max(score, 0.0), reasons=reasons, warnings=warnings, by_label=by_label)
