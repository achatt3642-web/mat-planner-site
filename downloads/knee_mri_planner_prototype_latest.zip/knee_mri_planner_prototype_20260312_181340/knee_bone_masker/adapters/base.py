from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from ..types import ModelSpec


class SegmenterBackend(ABC):
    @abstractmethod
    def predict(self, image: Any, model_spec: ModelSpec, work_dir: Path) -> Any:
        raise NotImplementedError
