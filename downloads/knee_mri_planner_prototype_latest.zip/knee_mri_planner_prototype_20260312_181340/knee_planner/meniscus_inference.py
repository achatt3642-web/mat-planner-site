from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import nibabel as nib
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


JOBS = [
    ("medial_length", "medial_length_mm"),
    ("lateral_length", "lateral_length_mm"),
    ("medial_width", "medial_width_mm"),
    ("lateral_width", "lateral_width_mm"),
]


def _bbox3d(mask: np.ndarray) -> tuple[int, int, int, int, int, int] | None:
    zz, yy, xx = np.where(mask)
    if zz.size == 0:
        return None
    return int(zz.min()), int(zz.max()), int(yy.min()), int(yy.max()), int(xx.min()), int(xx.max())


def _bbox_extent_mm(mask: np.ndarray, zooms: tuple[float, float, float]) -> tuple[float, float, float]:
    bb = _bbox3d(mask)
    if bb is None:
        return float("nan"), float("nan"), float("nan")
    z0, z1, y0, y1, x0, x1 = bb
    return (
        float((z1 - z0 + 1) * zooms[0]),
        float((y1 - y0 + 1) * zooms[1]),
        float((x1 - x0 + 1) * zooms[2]),
    )


def _center_crop_pad_3d(vol: np.ndarray, center_zyx: tuple[int, int, int], size_zyx: tuple[int, int, int]) -> np.ndarray:
    zc, yc, xc = center_zyx
    dz, dy, dx = size_zyx
    z0, y0, x0 = zc - dz // 2, yc - dy // 2, xc - dx // 2
    z1, y1, x1 = z0 + dz, y0 + dy, x0 + dx
    in_z0, in_y0, in_x0 = max(0, z0), max(0, y0), max(0, x0)
    in_z1, in_y1, in_x1 = min(vol.shape[0], z1), min(vol.shape[1], y1), min(vol.shape[2], x1)

    out = np.zeros((dz, dy, dx), dtype=vol.dtype)
    out_z0, out_y0, out_x0 = in_z0 - z0, in_y0 - y0, in_x0 - x0
    out_z1 = out_z0 + (in_z1 - in_z0)
    out_y1 = out_y0 + (in_y1 - in_y0)
    out_x1 = out_x0 + (in_x1 - in_x0)
    out[out_z0:out_z1, out_y0:out_y1, out_x0:out_x1] = vol[in_z0:in_z1, in_y0:in_y1, in_x0:in_x1]
    return out


def build_bone_volume(seg_path: Path, out_shape: tuple[int, int, int], crop_mm: tuple[float, float, float]) -> torch.Tensor:
    img = nib.load(str(seg_path))
    arr = np.asarray(img.get_fdata(), dtype=np.uint8)
    fem = (arr == 1) | (arr == 7)
    tib = (arr == 2) | (arr == 8)
    union = fem | tib
    bb = _bbox3d(union)
    if bb is None:
        vol = np.stack([fem.astype(np.float32), tib.astype(np.float32)], axis=0)
        ten = torch.from_numpy(vol).unsqueeze(0)
        ten = F.interpolate(ten, size=out_shape, mode="nearest")
        return ten.squeeze(0).to(torch.float32)

    z0, z1, y0, y1, x0, x1 = bb
    center = ((z0 + z1) // 2, (y0 + y1) // 2, (x0 + x1) // 2)
    zooms = img.header.get_zooms()[:3]
    size_vox = tuple(max(16, int(round(mm / max(1e-6, sp)))) for mm, sp in zip(crop_mm, zooms))
    fem_c = _center_crop_pad_3d(fem.astype(np.uint8), center, size_vox)
    tib_c = _center_crop_pad_3d(tib.astype(np.uint8), center, size_vox)
    vol = np.stack([fem_c.astype(np.float32), tib_c.astype(np.float32)], axis=0)
    ten = torch.from_numpy(vol).unsqueeze(0)
    ten = F.interpolate(ten, size=out_shape, mode="nearest")
    return ten.squeeze(0).to(torch.float32)


def extract_bone_geom_features(seg_path: Path) -> dict[str, float]:
    img = nib.load(str(seg_path))
    arr = np.asarray(img.get_fdata(), dtype=np.uint8)
    fem = (arr == 1) | (arr == 7)
    tib = (arr == 2) | (arr == 8)
    uni = fem | tib
    zooms = tuple(float(v) for v in img.header.get_zooms()[:3])
    feats: dict[str, float] = {
        "FemurVoxels": float(fem.sum()),
        "TibiaVoxels": float(tib.sum()),
        "UnionVoxels": float(uni.sum()),
    }
    fz, fy, fx = _bbox_extent_mm(fem, zooms)
    tz, ty, tx = _bbox_extent_mm(tib, zooms)
    uz, uy, ux = _bbox_extent_mm(uni, zooms)
    feats.update(
        {
            "FemurBBoxZ_mm": fz,
            "FemurBBoxY_mm": fy,
            "FemurBBoxX_mm": fx,
            "TibiaBBoxZ_mm": tz,
            "TibiaBBoxY_mm": ty,
            "TibiaBBoxX_mm": tx,
            "UnionBBoxZ_mm": uz,
            "UnionBBoxY_mm": uy,
            "UnionBBoxX_mm": ux,
        }
    )
    return feats


class BasicBlock3D(nn.Module):
    def __init__(self, in_ch: int, out_ch: int, stride: int = 1) -> None:
        super().__init__()
        self.conv1 = nn.Conv3d(in_ch, out_ch, 3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm3d(out_ch)
        self.conv2 = nn.Conv3d(out_ch, out_ch, 3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm3d(out_ch)
        self.relu = nn.ReLU(inplace=True)
        self.down = None
        if stride != 1 or in_ch != out_ch:
            self.down = nn.Sequential(
                nn.Conv3d(in_ch, out_ch, 1, stride=stride, bias=False),
                nn.BatchNorm3d(out_ch),
            )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        ident = x
        y = self.relu(self.bn1(self.conv1(x)))
        y = self.bn2(self.conv2(y))
        if self.down is not None:
            ident = self.down(x)
        return self.relu(y + ident)


class ResNet3DEncoder(nn.Module):
    def __init__(self, in_ch: int = 2, base_ch: int = 32) -> None:
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv3d(in_ch, base_ch, 7, stride=2, padding=3, bias=False),
            nn.BatchNorm3d(base_ch),
            nn.ReLU(inplace=True),
            nn.MaxPool3d(3, stride=2, padding=1),
        )
        self.layer1 = self._make_layer(base_ch, base_ch, 2, 1)
        self.layer2 = self._make_layer(base_ch, base_ch * 2, 2, 2)
        self.layer3 = self._make_layer(base_ch * 2, base_ch * 4, 2, 2)
        self.layer4 = self._make_layer(base_ch * 4, base_ch * 8, 2, 2)
        self.pool = nn.AdaptiveAvgPool3d((1, 1, 1))
        self.out_dim = base_ch * 8

    @staticmethod
    def _make_layer(in_ch: int, out_ch: int, blocks: int, stride: int) -> nn.Sequential:
        layers: list[nn.Module] = [BasicBlock3D(in_ch, out_ch, stride)]
        for _ in range(1, blocks):
            layers.append(BasicBlock3D(out_ch, out_ch, 1))
        return nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.stem(x)
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        return self.pool(x).flatten(1)


class BoneFusionResNet(nn.Module):
    def __init__(self, tab_dim: int, out_dim: int = 1, base_ch: int = 32) -> None:
        super().__init__()
        self.img = ResNet3DEncoder(in_ch=2, base_ch=base_ch)
        self.tab = nn.Sequential(
            nn.Linear(tab_dim, 128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.15),
            nn.Linear(128, 128),
            nn.ReLU(inplace=True),
        )
        self.gate = nn.Sequential(nn.Linear(128, self.img.out_dim), nn.Sigmoid())
        self.head = nn.Sequential(
            nn.Linear(self.img.out_dim + 128, 256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.25),
            nn.Linear(256, 128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.1),
            nn.Linear(128, out_dim),
        )

    def forward(self, x_img: torch.Tensor, x_tab: torch.Tensor) -> torch.Tensor:
        z = self.img(x_img)
        t = self.tab(x_tab)
        z = z * self.gate(t)
        return self.head(torch.cat([z, t], dim=1))


@dataclass
class PredictorConfig:
    model_root: Path
    device: str = "cpu"
    out_shape: tuple[int, int, int] = (96, 128, 128)
    crop_mm: tuple[float, float, float] = (120.0, 160.0, 160.0)
    max_members_per_target: int | None = 10


class MeniscusSizePredictor:
    def __init__(self, cfg: PredictorConfig):
        self.cfg = cfg
        self.device = torch.device(cfg.device if cfg.device != "auto" else ("cuda" if torch.cuda.is_available() else "cpu"))
        contract = cfg.model_root / "target_contract.json"
        if not contract.exists():
            raise RuntimeError(f"Missing target contract: {contract}")
        self.contract = json.loads(contract.read_text())

    def _checkpoint_paths(self, model_name: str) -> list[Path]:
        paths = sorted((self.cfg.model_root / model_name).glob("folds/seed*/fold*/best.pt"))
        if self.cfg.max_members_per_target is not None and len(paths) > self.cfg.max_members_per_target:
            return paths[: self.cfg.max_members_per_target]
        return paths

    def _build_features(self, seg_path: Path, side: str, demographics: dict[str, Any], feature_cols: list[str]) -> np.ndarray:
        geom = extract_bone_geom_features(seg_path)
        sex_code = 2
        sex = str(demographics.get("sex", "")).strip().upper()
        if sex == "M":
            sex_code = 0
        elif sex == "F":
            sex_code = 1
        base: dict[str, float] = {
            "age": float(demographics.get("age", np.nan)),
            "weight": float(demographics.get("weight", np.nan)),
            "height": float(demographics.get("height", np.nan)),
            "BMI": float(demographics.get("BMI", np.nan)),
            "sex_code": float(sex_code),
            "side_code": float(1 if str(side).lower().startswith("r") else 0),
        }
        base.update(geom)
        return np.array([base.get(c, np.nan) for c in feature_cols], dtype=np.float32)

    def predict(self, seg_path: Path, side: str, demographics: dict[str, Any]) -> dict[str, Any]:
        x_img = build_bone_volume(seg_path, self.cfg.out_shape, self.cfg.crop_mm).unsqueeze(0)
        if str(side).lower().startswith("r"):
            x_img = torch.flip(x_img, dims=[4])
        x_img = x_img.to(self.device)

        outputs: dict[str, Any] = {"predictions_mm": {}, "uncertainty_mm": {}, "members_used": {}}
        for model_name, target_col in JOBS:
            ckpts = self._checkpoint_paths(model_name)
            if not ckpts:
                continue
            preds = []
            n_members = 0
            for ckpt_path in ckpts:
                ck = torch.load(ckpt_path, map_location="cpu")
                fcols = list(ck.get("feature_cols", self.contract.get("feature_cols", [])))
                x = self._build_features(seg_path, side, demographics, fcols)
                x_mean = np.asarray(ck["x_mean"], dtype=np.float32)
                x_std = np.asarray(ck["x_std"], dtype=np.float32)
                miss = ~np.isfinite(x)
                if miss.any():
                    x[miss] = x_mean[miss]
                x = (x - x_mean) / np.clip(x_std, 1e-6, None)
                x = np.clip(x, -8.0, 8.0)
                x_tab = torch.tensor(x[None, :], dtype=torch.float32, device=self.device)

                model = BoneFusionResNet(tab_dim=len(fcols), out_dim=1, base_ch=32).to(self.device)
                model.load_state_dict(ck["model_state"], strict=True)
                model.eval()
                with torch.no_grad():
                    y_n = model(x_img, x_tab).squeeze().item()
                y_mean = float(np.asarray(ck["y_mean"], dtype=np.float32)[0])
                y_std = float(np.asarray(ck["y_std"], dtype=np.float32)[0])
                y = y_n * y_std + y_mean
                lo = float(ck.get("pred_clip_lo_mm", np.nan))
                hi = float(ck.get("pred_clip_hi_mm", np.nan))
                if np.isfinite(lo) and np.isfinite(hi) and hi > lo:
                    y = float(np.clip(y, lo, hi))
                preds.append(y)
                n_members += 1
            if preds:
                outputs["predictions_mm"][target_col] = float(np.median(preds))
                outputs["uncertainty_mm"][target_col] = float(np.std(preds))
                outputs["members_used"][target_col] = int(n_members)
        return outputs

