from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            b = f.read(chunk_size)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def hash_tree_manifest(path: Path) -> tuple[str, int, int]:
    h = hashlib.sha256()
    n_files = 0
    n_bytes = 0
    for p in sorted(x for x in path.rglob("*") if x.is_file()):
        rel = p.relative_to(path).as_posix()
        size = p.stat().st_size
        n_files += 1
        n_bytes += size
        h.update(rel.encode("utf-8"))
        h.update(str(size).encode("utf-8"))
    return h.hexdigest(), n_files, n_bytes


def _safe_stats(path: Path | None) -> dict[str, Any]:
    if path is None:
        return {"exists": False}
    if not path.exists():
        return {"exists": False, "path": str(path)}
    if path.is_file():
        return {
            "exists": True,
            "path": str(path),
            "kind": "file",
            "size_bytes": path.stat().st_size,
            "sha256": sha256_file(path),
        }
    digest, n_files, n_bytes = hash_tree_manifest(path)
    return {
        "exists": True,
        "path": str(path),
        "kind": "directory",
        "manifest_sha256": digest,
        "files": n_files,
        "size_bytes": n_bytes,
    }


def build_registry(
    *,
    app_root: Path,
    model_yaml: Path,
    meniscus_model_root: Path,
    out_json: Path,
) -> Path:
    data = yaml.safe_load(model_yaml.read_text())
    if not isinstance(data, list):
        raise RuntimeError(f"Model YAML must be a list: {model_yaml}")

    seg_models: list[dict[str, Any]] = []
    for m in data:
        item: dict[str, Any] = {
            "id": m.get("id"),
            "backend": m.get("backend"),
            "priority": m.get("priority"),
            "description": m.get("description"),
            "model_path": m.get("model_path"),
            "checkpoint_name": m.get("checkpoint_name"),
            "label_map": m.get("label_map", {}),
            "backend_kwargs": m.get("backend_kwargs", {}),
        }
        mp = m.get("model_path")
        item["artifact"] = _safe_stats(Path(mp)) if mp else {"exists": False}
        seg_models.append(item)

    contract = meniscus_model_root / "target_contract.json"
    member_paths = sorted(meniscus_model_root.glob("*/folds/seed*/fold*/best.pt"))
    members = []
    for p in member_paths:
        members.append(
            {
                "path": str(p),
                "size_bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            }
        )

    app_files = [
        app_root / "pyproject.toml",
        app_root / "example_models.yaml",
        app_root / "knee_planner" / "app_gradio.py",
        app_root / "knee_planner" / "meniscus_inference.py",
        app_root / "knee_planner" / "segmenters.py",
        app_root / "knee_planner" / "render.py",
        app_root / "knee_planner" / "horns.py",
        app_root / "knee_planner" / "report.py",
    ]
    app_manifest = []
    for p in app_files:
        app_manifest.append({"path": str(p), **_safe_stats(p)})

    out = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "app_root": str(app_root),
        "segmentation_model_registry": {
            "yaml_path": str(model_yaml),
            "yaml_sha256": sha256_file(model_yaml),
            "models": seg_models,
        },
        "meniscus_size_model": {
            "root": str(meniscus_model_root),
            "contract": _safe_stats(contract),
            "checkpoint_count": len(members),
            "checkpoints": members,
        },
        "application_files": app_manifest,
    }

    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps(out, indent=2, sort_keys=True))
    return out_json


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Build model/version registry JSON for reproducible runs")
    p.add_argument("--app-root", type=Path, required=True)
    p.add_argument("--model-yaml", type=Path, required=True)
    p.add_argument("--meniscus-model-root", type=Path, required=True)
    p.add_argument("--out-json", type=Path, required=True)
    return p


def main() -> None:
    args = build_parser().parse_args()
    out = build_registry(
        app_root=args.app_root,
        model_yaml=args.model_yaml,
        meniscus_model_root=args.meniscus_model_root,
        out_json=args.out_json,
    )
    print(str(out))


if __name__ == "__main__":
    main()
