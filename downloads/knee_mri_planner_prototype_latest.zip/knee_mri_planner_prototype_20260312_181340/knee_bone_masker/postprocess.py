from __future__ import annotations

from typing import Any, Dict

import numpy as np

from .types import STANDARD_LABELS


def _require_sitk():
    import SimpleITK as sitk
    return sitk


def standardize_labels(mask: Any, label_map: Dict[int, str]) -> Any:
    """Map arbitrary model labels onto standardized labels.

    Standard output labels:
      1 = femur
      2 = tibia
    """
    sitk = _require_sitk()
    arr = sitk.GetArrayFromImage(mask)
    out = np.zeros(arr.shape, dtype=np.uint8)

    normalized = {int(k): str(v).strip().lower() for k, v in (label_map or {}).items()}
    if not normalized:
        unique = [int(v) for v in np.unique(arr) if int(v) != 0]
        if unique == [1, 2]:
            normalized = {1: "femur", 2: "tibia"}
        else:
            raise ValueError("No label_map provided and labels are not already standardized.")

    for src_label, name in normalized.items():
        if name not in STANDARD_LABELS:
            continue
        out[arr == src_label] = STANDARD_LABELS[name]

    result = sitk.GetImageFromArray(out)
    result.CopyInformation(mask)
    return result


def _largest_connected_component(binary_image: Any) -> Any:
    sitk = _require_sitk()
    cc = sitk.ConnectedComponent(binary_image)
    stats = sitk.LabelShapeStatisticsImageFilter()
    stats.Execute(cc)
    if not stats.GetLabels():
        return sitk.Cast(binary_image > 0, sitk.sitkUInt8)
    largest = max(stats.GetLabels(), key=lambda x: stats.GetNumberOfPixels(x))
    return sitk.Cast(cc == largest, sitk.sitkUInt8)


def keep_largest_component_per_label(mask: Any) -> Any:
    sitk = _require_sitk()
    out = sitk.Image(mask.GetSize(), sitk.sitkUInt8)
    out.CopyInformation(mask)
    for label in STANDARD_LABELS.values():
        binary = sitk.Cast(mask == label, sitk.sitkUInt8)
        largest = _largest_connected_component(binary)
        out = out + sitk.Cast(largest, sitk.sitkUInt8) * int(label)
    return out


def fill_holes_per_label(mask: Any) -> Any:
    sitk = _require_sitk()
    out = sitk.Image(mask.GetSize(), sitk.sitkUInt8)
    out.CopyInformation(mask)
    for label in STANDARD_LABELS.values():
        binary = sitk.Cast(mask == label, sitk.sitkUInt8)
        filled = sitk.BinaryFillhole(binary)
        out = out + sitk.Cast(filled, sitk.sitkUInt8) * int(label)
    return out


def split_binary_masks(mask: Any) -> Dict[str, Any]:
    sitk = _require_sitk()
    return {
        "femur": sitk.Cast(mask == STANDARD_LABELS["femur"], sitk.sitkUInt8),
        "tibia": sitk.Cast(mask == STANDARD_LABELS["tibia"], sitk.sitkUInt8),
    }
