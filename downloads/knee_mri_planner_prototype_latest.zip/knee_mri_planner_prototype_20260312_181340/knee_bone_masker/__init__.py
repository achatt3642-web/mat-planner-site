from .pipeline import BoneMaskPipeline

__all__ = ["BoneMaskPipeline"]
