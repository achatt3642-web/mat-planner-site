from __future__ import annotations

from dataclasses import dataclass
from typing import List

from .registry import score_model_for_series
from .types import LoadedVolume, ModelSpec


@dataclass
class RouteChoice:
    score: float
    volume: LoadedVolume
    model_spec: ModelSpec


def build_route_plan(volumes: List[LoadedVolume], specs: List[ModelSpec]) -> List[RouteChoice]:
    choices: List[RouteChoice] = []
    for volume in volumes:
        for spec in specs:
            score = score_model_for_series(spec, volume.fingerprint)
            if score > -1e8:
                choices.append(RouteChoice(score=score, volume=volume, model_spec=spec))
    return sorted(choices, key=lambda c: c.score, reverse=True)
