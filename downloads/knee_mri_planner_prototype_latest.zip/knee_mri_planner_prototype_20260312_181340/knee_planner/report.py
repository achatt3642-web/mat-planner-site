from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


def _fmt(v: Any, digits: int = 2) -> str:
    try:
        return f"{float(v):.{digits}f}"
    except Exception:
        return "NA"


def build_pdf_report(
    out_pdf: Path,
    *,
    source_input: str,
    run_dir: Path,
    side: str,
    demographics: dict[str, Any],
    predictions_mm: dict[str, float],
    uncertainty_mm: dict[str, float],
    members_used: dict[str, int],
    horns: dict[str, Any],
    bone_mask_path: Path,
    femur_mask_path: Path,
    tibia_mask_path: Path,
    model_registry_json: Path | None = None,
) -> Path:
    out_pdf.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(str(out_pdf), pagesize=letter, title="Knee MRI Planning Report")
    styles = getSampleStyleSheet()
    body = styles["BodyText"]
    heading = styles["Heading2"]
    title = styles["Title"]

    elements: list[Any] = []
    elements.append(Paragraph("Knee MRI Bone Segmentation + Meniscus Sizing Report (Research Use Only)", title))
    elements.append(Spacer(1, 8))

    meta_rows = [
        ["Run timestamp", datetime.now().isoformat(timespec="seconds")],
        ["Source input", source_input],
        ["Run directory", str(run_dir)],
        ["Knee side", side],
        ["Bone mask", str(bone_mask_path)],
        ["Femur mask", str(femur_mask_path)],
        ["Tibia mask", str(tibia_mask_path)],
    ]
    if model_registry_json is not None:
        meta_rows.append(["Model registry", str(model_registry_json)])

    meta_tbl = Table(meta_rows, colWidths=[150, 380])
    meta_tbl.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.4, colors.black),
                ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#f0f4f8")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ]
        )
    )
    elements.append(meta_tbl)
    elements.append(Spacer(1, 12))

    elements.append(Paragraph("Input Demographics", heading))
    dem_rows = [["Field", "Value"]]
    for key in ["age", "sex", "height", "weight", "BMI"]:
        dem_rows.append([key, str(demographics.get(key, "NA"))])
    dem_tbl = Table(dem_rows, colWidths=[180, 350])
    dem_tbl.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.4, colors.black),
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dbeafe")),
                ("BACKGROUND", (0, 1), (0, -1), colors.HexColor("#f8fafc")),
            ]
        )
    )
    elements.append(dem_tbl)
    elements.append(Spacer(1, 12))

    elements.append(Paragraph("Predicted Meniscus Dimensions", heading))
    pred_rows = [["Target", "Prediction (mm)", "Uncertainty SD (mm)", "Ensemble members"]]
    ordered = [
        "medial_width_mm",
        "lateral_width_mm",
        "medial_length_mm",
        "lateral_length_mm",
    ]
    for k in ordered:
        pred_rows.append(
            [
                k,
                _fmt(predictions_mm.get(k)),
                _fmt(uncertainty_mm.get(k)),
                str(members_used.get(k, "NA")),
            ]
        )

    pred_tbl = Table(pred_rows, colWidths=[170, 120, 130, 110])
    pred_tbl.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.4, colors.black),
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#bfdbfe")),
                ("BACKGROUND", (0, 1), (0, -1), colors.HexColor("#eff6ff")),
            ]
        )
    )
    elements.append(pred_tbl)
    elements.append(Spacer(1, 12))

    elements.append(Paragraph("Estimated Horn Coordinates (mm)", heading))
    horn_rows = [["Compartment", "Anterior horn (x, y, z)", "Posterior horn (x, y, z)"]]
    for comp in ["medial", "lateral"]:
        item = horns.get(comp)
        if item is None:
            horn_rows.append([comp, "NA", "NA"])
            continue
        horn_rows.append(
            [
                comp,
                "(" + ", ".join(_fmt(v, 1) for v in item.anterior_xyz_mm) + ")",
                "(" + ", ".join(_fmt(v, 1) for v in item.posterior_xyz_mm) + ")",
            ]
        )
    horn_tbl = Table(horn_rows, colWidths=[100, 220, 220])
    horn_tbl.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.4, colors.black),
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#c7d2fe")),
                ("BACKGROUND", (0, 1), (0, -1), colors.HexColor("#eef2ff")),
            ]
        )
    )
    elements.append(horn_tbl)
    elements.append(Spacer(1, 10))
    elements.append(
        Paragraph(
            "Research-only output. Not for clinical decision-making without independent validation and regulatory review.",
            body,
        )
    )

    doc.build(elements)
    return out_pdf
