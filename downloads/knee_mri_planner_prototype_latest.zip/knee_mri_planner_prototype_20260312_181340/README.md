# Knee MRI Planner Prototype (Research-Only)

Local desktop prototype for:
- DICOM or NIfTI knee MRI input
- femur/tibia bone segmentation
- meniscus size prediction (medial/lateral width + length) via 3D CNN
- estimated horn landmark coordinates
- interactive 3D rendering with toggleable structures
- PDF + JSON report output

Supported targets:
- macOS
- Windows

## What this prototype does now

1. Accepts either:
- NIfTI file upload
- DICOM series directory path

2. Runs bone segmentation through the model registry:
- Prototype fallback segmenter (`python_callable`) is bundled and runnable immediately.
- nnU-Net entries are included as examples and activate once real checkpoints are configured.

3. Runs meniscus size prediction using your trained 3D CNN checkpoints:
- expected model root default:
  `/Users/abhichatterjee/Documents/Meniscus_project_noOA/Verda_Results/bone_lenwid_v2_guarded_20260309_004625`

4. Produces 3D planning scene:
- femur/tibia meshes
- meniscus allograft overlay curves (medial/lateral)
- anterior/posterior horn markers
- Plotly legend toggles each structure

5. Exports:
- `planning_report.pdf`
- `run_summary.json`
- `model_registry.json` (artifact/version manifest)

## Install and run

```bash
cd /Users/abhichatterjee/Documents/Meniscus_project_noOA/prototype/knee_mri_planner
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m knee_planner.app_gradio
```

Or use launcher scripts:
- macOS: `launch_mac.command`
- Windows: `launch_windows.bat`

## Build release zip + website downloads

```bash
cd /Users/abhichatterjee/Documents/Meniscus_project_noOA/prototype/knee_mri_planner
source .venv/bin/activate
python scripts/build_release.py \
  --app-root /Users/abhichatterjee/Documents/Meniscus_project_noOA/prototype/knee_mri_planner \
  --meniscus-model-root /Users/abhichatterjee/Documents/Meniscus_project_noOA/Verda_Results/bone_lenwid_v2_guarded_20260309_004625
```

Outputs:
- `dist/knee_mri_planner_prototype_<timestamp>.zip`
- `dist/model_registry.json`
- `site/downloads/knee_mri_planner_prototype_latest.zip`
- `site/downloads/model_registry.json`

## Model version registry

The registry builder stores reproducibility metadata including:
- segmentation registry YAML hash
- segmentation model entries and artifact stats
- meniscus checkpoint paths + SHA256
- application file hashes

Command:

```bash
python -m knee_planner.model_registry \
  --app-root /Users/abhichatterjee/Documents/Meniscus_project_noOA/prototype/knee_mri_planner \
  --model-yaml /Users/abhichatterjee/Documents/Meniscus_project_noOA/prototype/knee_mri_planner/example_models.yaml \
  --meniscus-model-root /Users/abhichatterjee/Documents/Meniscus_project_noOA/Verda_Results/bone_lenwid_v2_guarded_20260309_004625 \
  --out-json /Users/abhichatterjee/Documents/Meniscus_project_noOA/prototype/knee_mri_planner/dist/model_registry.json
```

## Third-party model licenses

If you bundle third-party model weights in a distributed app package, you must comply with those model/data licenses. Keeping user-supplied model paths external (not bundled) minimizes redistribution risk.

## Website hosting plan

The `site/` folder is a static website package and can be hosted on a Google subdomain via Google Cloud Storage + Load Balancer/Cloud DNS.

Required to publish:
- authenticated Google Cloud project access
- DNS control for the chosen subdomain

## Current scope exclusions

- ACL/PCL segmentation is intentionally deferred.
- Clinical/regulatory deployment is out of scope in this prototype.
- Security hardening/encryption is not included (per current requirement).
