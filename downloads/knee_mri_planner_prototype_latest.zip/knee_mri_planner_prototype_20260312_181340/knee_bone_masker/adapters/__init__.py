from .base import SegmenterBackend
from .nnunetv2_adapter import NnUNetV2Adapter
from .python_callable_adapter import PythonCallableAdapter
from .subprocess_adapter import SubprocessAdapter


def get_backend(name: str) -> SegmenterBackend:
    normalized = name.strip().lower()
    if normalized == "nnunetv2":
        return NnUNetV2Adapter()
    if normalized == "python_callable":
        return PythonCallableAdapter()
    if normalized == "subprocess":
        return SubprocessAdapter()
    raise ValueError(f"Unknown backend: {name}")
