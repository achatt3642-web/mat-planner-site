from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import nibabel as nib
import numpy as np


@dataclass
class HornEstimate:
    anterior_xyz_mm: tuple[float, float, float]
    posterior_xyz_mm: tuple[float, float, float]


def _to_xyz_mm(idx_zyx: np.ndarray, spacing_zyx: tuple[float, float, float]) -> tuple[float, float, float]:
    z, y, x = idx_zyx.astype(float).tolist()
    sz, sy, sx = spacing_zyx
    return (x * sx, y * sy, z * sz)


def _plateau_compartment_points(
    coords_zyx: np.ndarray,
    spacing_zyx: tuple[float, float, float],
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return (plateau_points, lateral_points, medial_points) in z,y,x index space."""
    # Axis convention: z=AP, y=SI, x=ML.
    y_sup = np.percentile(coords_zyx[:, 1], 4.0)  # superior plateau vicinity
    band_vox = max(3, int(round(12.0 / max(spacing_zyx[1], 1e-6))))  # ~12 mm band
    plateau = coords_zyx[coords_zyx[:, 1] <= (y_sup + band_vox)]
    if plateau.shape[0] < 1000:
        band_vox = max(band_vox, int(round(20.0 / max(spacing_zyx[1], 1e-6))))
        plateau = coords_zyx[coords_zyx[:, 1] <= (y_sup + band_vox)]
    if plateau.shape[0] == 0:
        plateau = coords_zyx

    x_mid = np.median(plateau[:, 2])
    lateral = plateau[plateau[:, 2] <= x_mid]
    medial = plateau[plateau[:, 2] > x_mid]
    if lateral.shape[0] == 0:
        lateral = plateau
    if medial.shape[0] == 0:
        medial = plateau
    return plateau, lateral, medial


def _horns_from_compartment(
    comp_coords: np.ndarray,
    spacing_zyx: tuple[float, float, float],
    length_mm: float,
) -> HornEstimate:
    # Use plateau center for ML/SI; AP endpoints from predicted length, clipped to anatomy.
    center = np.median(comp_coords, axis=0).astype(float)  # z,y,x
    z_vals = comp_coords[:, 0].astype(float)
    z_min_mm = float(np.min(z_vals) * spacing_zyx[0])
    z_max_mm = float(np.max(z_vals) * spacing_zyx[0])
    center_ap_mm = float(center[0] * spacing_zyx[0])

    half_len = max(6.0, float(length_mm) * 0.5)
    ant_ap_mm = center_ap_mm - half_len
    post_ap_mm = center_ap_mm + half_len
    # Keep root points inside compartment AP bounds.
    ant_ap_mm = max(z_min_mm + 2.0, ant_ap_mm)
    post_ap_mm = min(z_max_mm - 2.0, post_ap_mm)
    if post_ap_mm <= ant_ap_mm:
        ant_ap_mm = float(np.percentile(z_vals, 20.0) * spacing_zyx[0])
        post_ap_mm = float(np.percentile(z_vals, 80.0) * spacing_zyx[0])

    ant_idx = np.array([ant_ap_mm / spacing_zyx[0], center[1], center[2]], dtype=float)
    post_idx = np.array([post_ap_mm / spacing_zyx[0], center[1], center[2]], dtype=float)
    return HornEstimate(_to_xyz_mm(ant_idx, spacing_zyx), _to_xyz_mm(post_idx, spacing_zyx))


def estimate_horns_from_tibia(
    seg_path: Path,
    medial_width_mm: float,
    lateral_width_mm: float,
    medial_length_mm: float,
    lateral_length_mm: float,
) -> dict[str, HornEstimate]:
    """Estimate meniscal horn roots from tibial plateau geometry.

    Axis convention:
    - array axis0 (z): AP
    - array axis1 (y): SI
    - array axis2 (x): ML
    Output coordinates are plotted as (ML, SI, AP) in mm.
    """
    img = nib.load(str(seg_path))
    arr = np.asarray(img.get_fdata(), dtype=np.uint8)
    tib = (arr == 2) | (arr == 8)
    if tib.sum() == 0:
        zero = HornEstimate((0.0, 0.0, 0.0), (0.0, 0.0, 0.0))
        return {"medial": zero, "lateral": zero}

    coords = np.argwhere(tib)  # z,y,x
    spacing = tuple(float(v) for v in img.header.get_zooms()[:3])
    _, lateral, medial = _plateau_compartment_points(coords, spacing)

    return {
        "medial": _horns_from_compartment(medial, spacing, medial_length_mm),
        "lateral": _horns_from_compartment(lateral, spacing, lateral_length_mm),
    }
