from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any

import gradio as gr
import nibabel as nib
import numpy as np

from knee_bone_masker.pipeline import BoneMaskPipeline

from .horns import estimate_horns_from_tibia
from .meniscus_inference import MeniscusSizePredictor, PredictorConfig
from .model_registry import build_registry
from .render import create_knee_scene
from .report import build_pdf_report


APP_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_REGISTRY = APP_ROOT / "example_models.yaml"
DEFAULT_MODEL_ROOT = Path(
    "/Users/abhichatterjee/Documents/Meniscus_project_noOA/Verda_Results/bone_lenwid_v2_guarded_20260309_004625"
)
DEFAULT_OUTPUT_ROOT = Path("/Users/abhichatterjee/Documents/Meniscus_project_noOA/Knee_MRI_Planner_Output")


def _try_use_existing_label_nifti(src_path: Path, seg_dir: Path) -> tuple[bool, Path | None, str]:
    """If NIfTI already contains bone labels, standardize and use it directly.

    Accepted source labels:
    - 1/2 (femur/tibia already standardized), or
    - 7/8(/9) from total-knee style labels.
    """
    if not src_path.is_file() or not (src_path.name.endswith(".nii") or src_path.name.endswith(".nii.gz")):
        return False, None, "not_nifti"

    img = nib.load(str(src_path))
    arr = np.asarray(img.get_fdata())
    if arr.ndim != 3:
        return False, None, "not_3d"

    arr_i = np.rint(arr)
    if not np.allclose(arr, arr_i, atol=1e-3):
        return False, None, "not_integer_label_map"
    arr_i = arr_i.astype(np.int16)
    uniq = set(np.unique(arr_i).tolist())
    if not uniq:
        return False, None, "empty"

    allowed = {0, 1, 2, 7, 8, 9}
    if not uniq.issubset(allowed):
        return False, None, "label_set_not_supported"

    fem = (arr_i == 1) | (arr_i == 7)
    tib = (arr_i == 2) | (arr_i == 8)
    if int(fem.sum()) < 1000 or int(tib.sum()) < 1000:
        return False, None, "missing_femur_or_tibia"

    seg_dir.mkdir(parents=True, exist_ok=True)
    out = np.zeros(arr_i.shape, dtype=np.uint8)
    out[fem] = 1
    out[tib] = 2

    hdr = img.header.copy()
    hdr.set_data_dtype(np.uint8)
    bone_path = seg_dir / "bone_mask.nii.gz"
    fem_path = seg_dir / "femur_mask.nii.gz"
    tib_path = seg_dir / "tibia_mask.nii.gz"
    nib.save(nib.Nifti1Image(out, img.affine, hdr), str(bone_path))
    nib.save(nib.Nifti1Image(fem.astype(np.uint8), img.affine, hdr), str(fem_path))
    nib.save(nib.Nifti1Image(tib.astype(np.uint8), img.affine, hdr), str(tib_path))

    return True, bone_path, "provided_labeled_nifti_direct"


def _run_once(
    nifti_file: str | None,
    dicom_dir: str,
    side: str,
    age: float,
    sex: str,
    height: float,
    weight: float,
    bmi: float,
    registry_path: str,
    meniscus_model_root: str,
    output_root: str,
    device: str,
) -> tuple[str, Any, str, str, str]:
    src_path: Path | None = None
    if nifti_file:
        src_path = Path(nifti_file)
    else:
        d = Path(dicom_dir.strip()) if dicom_dir else None
        if d and d.exists() and d.is_dir():
            src_path = d

    if src_path is None:
        raise gr.Error("Provide either a NIfTI file or a valid DICOM directory path.")

    reg = Path(registry_path).expanduser().resolve()
    if not reg.exists():
        raise gr.Error(f"Registry not found: {reg}")

    model_root = Path(meniscus_model_root).expanduser().resolve()
    if not (model_root / "target_contract.json").exists():
        raise gr.Error(f"Meniscus model contract not found: {model_root / 'target_contract.json'}")

    root = Path(output_root).expanduser().resolve()
    run_id = datetime.now().strftime("run_%Y%m%d_%H%M%S")
    run_dir = root / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    seg_dir = run_dir / "segmentation"

    selected_segmentation_model: str | None = None
    used_existing, existing_bone_path, reason = _try_use_existing_label_nifti(src_path, seg_dir)
    if used_existing and existing_bone_path is not None:
        bone_mask_path = existing_bone_path
        selected_segmentation_model = "provided_labeled_nifti_direct"
    else:
        pipeline = BoneMaskPipeline(registry_path=reg)
        seg_result = pipeline.segment(src_path, seg_dir)
        if not seg_result.success or seg_result.output_mask_path is None:
            raise gr.Error(f"Segmentation failed. Inspect report: {seg_result.report_path}")
        bone_mask_path = seg_result.output_mask_path
        selected_segmentation_model = seg_result.selected_model.id if seg_result.selected_model else f"router_unknown ({reason})"

    demographics = {
        "age": float(age),
        "sex": str(sex),
        "height": float(height),
        "weight": float(weight),
        "BMI": float(bmi),
    }

    predictor = MeniscusSizePredictor(
        PredictorConfig(
            model_root=model_root,
            device=device,
            out_shape=(96, 128, 128),
            crop_mm=(120.0, 160.0, 160.0),
            max_members_per_target=10,
        )
    )
    pred = predictor.predict(bone_mask_path, side=side, demographics=demographics)

    preds = pred.get("predictions_mm", {})
    horns = estimate_horns_from_tibia(
        bone_mask_path,
        medial_width_mm=float(preds.get("medial_width_mm", 28.0)),
        lateral_width_mm=float(preds.get("lateral_width_mm", 30.0)),
        medial_length_mm=float(preds.get("medial_length_mm", 40.0)),
        lateral_length_mm=float(preds.get("lateral_length_mm", 36.0)),
    )

    fig = create_knee_scene(
        bone_mask_path,
        predictions=preds,
        horns=horns,
        title="Knee 3D Planning View (Femur/Tibia + Meniscus Allograft + Horn Landmarks)",
    )
    scene_html = run_dir / "knee_scene.html"
    fig.write_html(str(scene_html), include_plotlyjs="cdn")

    model_registry_json = run_dir / "model_registry.json"
    build_registry(
        app_root=APP_ROOT,
        model_yaml=reg,
        meniscus_model_root=model_root,
        out_json=model_registry_json,
    )

    pdf_path = run_dir / "planning_report.pdf"
    build_pdf_report(
        pdf_path,
        source_input=str(src_path),
        run_dir=run_dir,
        side=side,
        demographics=demographics,
        predictions_mm=pred.get("predictions_mm", {}),
        uncertainty_mm=pred.get("uncertainty_mm", {}),
        members_used=pred.get("members_used", {}),
        horns=horns,
        bone_mask_path=run_dir / "segmentation" / "bone_mask.nii.gz",
        femur_mask_path=run_dir / "segmentation" / "femur_mask.nii.gz",
        tibia_mask_path=run_dir / "segmentation" / "tibia_mask.nii.gz",
        model_registry_json=model_registry_json,
    )

    summary = {
        "run_id": run_id,
        "source": str(src_path),
        "side": side,
        "demographics": demographics,
        "selected_segmentation_model": selected_segmentation_model,
        "bone_mask": str(bone_mask_path),
        "predictions_mm": pred.get("predictions_mm", {}),
        "uncertainty_mm": pred.get("uncertainty_mm", {}),
        "members_used": pred.get("members_used", {}),
        "report_pdf": str(pdf_path),
        "scene_html": str(scene_html),
        "model_registry": str(model_registry_json),
    }
    summary_path = run_dir / "run_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True))

    status = (
        f"Run complete: `{run_id}`\n"
        f"- Source: `{src_path}`\n"
        f"- Segmentation model: `{summary['selected_segmentation_model']}`\n"
        f"- Output folder: `{run_dir}`\n"
        f"- Medial width: `{preds.get('medial_width_mm', float('nan')):.2f} mm`\n"
        f"- Lateral width: `{preds.get('lateral_width_mm', float('nan')):.2f} mm`\n"
        f"- Medial length: `{preds.get('medial_length_mm', float('nan')):.2f} mm`\n"
        f"- Lateral length: `{preds.get('lateral_length_mm', float('nan')):.2f} mm`"
    )

    files_block = "\n".join(
        [
            str(run_dir / "segmentation" / "bone_mask.nii.gz"),
            str(run_dir / "segmentation" / "femur_mask.nii.gz"),
            str(run_dir / "segmentation" / "tibia_mask.nii.gz"),
            str(scene_html),
            str(pdf_path),
            str(model_registry_json),
            str(summary_path),
        ]
    )
    return status, fig, str(pdf_path), str(summary_path), files_block


def build_demo() -> gr.Blocks:
    with gr.Blocks(title="Knee MRI Planner Prototype") as demo:
        gr.Markdown(
            "# Knee MRI Planner Prototype\n"
            "Research-only desktop prototype for femur/tibia segmentation, 3D planning view, and meniscus size prediction."
        )

        with gr.Row():
            with gr.Column(scale=1):
                nifti_file = gr.File(label="NIfTI MRI (optional if using DICOM folder)", file_types=[".nii", ".gz"], type="filepath")
                dicom_dir = gr.Textbox(label="DICOM folder path (optional if NIfTI is uploaded)", placeholder="/path/to/dicom_series_dir")
                side = gr.Dropdown(choices=["left", "right"], value="left", label="Knee side")

                with gr.Row():
                    age = gr.Number(value=55, label="Age")
                    sex = gr.Dropdown(choices=["M", "F", "U"], value="U", label="Sex")
                with gr.Row():
                    height = gr.Number(value=170.0, label="Height (cm)")
                    weight = gr.Number(value=75.0, label="Weight (kg)")
                    bmi = gr.Number(value=26.0, label="BMI")

                registry_path = gr.Textbox(label="Segmentation model registry YAML", value=str(DEFAULT_REGISTRY))
                meniscus_model_root = gr.Textbox(label="3D CNN model root", value=str(DEFAULT_MODEL_ROOT))
                output_root = gr.Textbox(label="Output root", value=str(DEFAULT_OUTPUT_ROOT))
                device = gr.Dropdown(choices=["cpu", "cuda", "mps", "auto"], value="auto", label="Inference device")

                run_btn = gr.Button("Run Planning Pipeline", variant="primary")

            with gr.Column(scale=2):
                status = gr.Markdown(label="Status")
                plot = gr.Plot(label="3D Planning View")
                report_file = gr.File(label="PDF report")
                summary_file = gr.File(label="Run summary JSON")
                files_block = gr.Textbox(label="Generated files", lines=9)

        run_btn.click(
            fn=_run_once,
            inputs=[
                nifti_file,
                dicom_dir,
                side,
                age,
                sex,
                height,
                weight,
                bmi,
                registry_path,
                meniscus_model_root,
                output_root,
                device,
            ],
            outputs=[status, plot, report_file, summary_file, files_block],
        )

    return demo


def main() -> None:
    demo = build_demo()
    demo.launch(server_name="127.0.0.1", server_port=7860, inbrowser=True)


if __name__ == "__main__":
    main()
