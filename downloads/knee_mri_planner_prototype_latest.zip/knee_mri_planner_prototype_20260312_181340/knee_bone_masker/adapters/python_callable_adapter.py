from __future__ import annotations

from importlib import import_module
from pathlib import Path
from typing import Any

from .base import SegmenterBackend
from ..types import ModelSpec


class PythonCallableAdapter(SegmenterBackend):
    """Call an arbitrary Python function.

    Registry example:
      backend_kwargs:
        callable: my_package.segmenters.my_model:segment

    The callable must accept:
      segment(image, model_spec, work_dir) -> SimpleITK.Image
    """

    def predict(self, image: Any, model_spec: ModelSpec, work_dir: Path) -> Any:
        callable_ref = (model_spec.backend_kwargs or {}).get("callable")
        if not callable_ref or ":" not in callable_ref:
            raise ValueError(
                f"Model {model_spec.id} must define backend_kwargs.callable as module:function"
            )
        module_name, func_name = callable_ref.split(":", 1)
        module = import_module(module_name)
        func = getattr(module, func_name)
        return func(image=image, model_spec=model_spec, work_dir=work_dir)
