from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import json

from .types import LoadedVolume, SeriesFingerprint


class InputError(RuntimeError):
    pass


def _require_sitk():
    try:
        import SimpleITK as sitk
    except ImportError as exc:
        raise InputError("SimpleITK is required for reading MRI volumes.") from exc
    return sitk


def _try_import_pydicom():
    try:
        import pydicom
    except Exception:
        return None
    return pydicom


@dataclass
class DicomSeriesCandidate:
    series_id: str
    source_dir: Path
    files: List[Path]
    first_file_metadata: Dict[str, Any]


def _orientation_from_direction(direction: Sequence[float]) -> str:
    # direction is a 3x3 flattened matrix in SimpleITK LPS coordinates.
    # Slice direction = third column of the direction matrix.
    if len(direction) != 9:
        return "UNKNOWN"
    col3 = (abs(direction[2]), abs(direction[5]), abs(direction[8]))
    axis = max(range(3), key=lambda i: col3[i])
    # LPS axes: x=LR, y=AP, z=SI. Slice normal along x->sagittal, y->coronal, z->axial.
    return {0: "SAGITTAL", 1: "CORONAL", 2: "AXIAL"}.get(axis, "UNKNOWN")


def _safe_float(value: Any) -> Optional[float]:
    try:
        return float(value)
    except Exception:
        return None


def _read_dicom_header(first_file: Path) -> Dict[str, Any]:
    pydicom = _try_import_pydicom()
    if pydicom is None:
        return {}

    ds = pydicom.dcmread(str(first_file), stop_before_pixels=True, force=True)

    def get(name: str, default: Any = None) -> Any:
        return getattr(ds, name, default)

    return {
        "Modality": get("Modality"),
        "Manufacturer": get("Manufacturer"),
        "ManufacturerModelName": get("ManufacturerModelName"),
        "MagneticFieldStrength": _safe_float(get("MagneticFieldStrength")),
        "SeriesDescription": str(get("SeriesDescription", "") or ""),
        "SequenceName": str(get("SequenceName", "") or ""),
        "ProtocolName": str(get("ProtocolName", "") or ""),
        "ScanningSequence": str(get("ScanningSequence", "") or ""),
        "ImageType": "\\".join(get("ImageType", [])) if get("ImageType", None) else None,
    }


def discover_dicom_series(path: str | Path) -> List[DicomSeriesCandidate]:
    sitk = _require_sitk()
    path = Path(path)
    if not path.is_dir():
        raise InputError(f"Not a directory: {path}")

    reader = sitk.ImageSeriesReader()
    series_ids = reader.GetGDCMSeriesIDs(str(path))
    if not series_ids:
        raise InputError(f"No DICOM series found in {path}")

    candidates: List[DicomSeriesCandidate] = []
    for series_id in series_ids:
        files = [Path(p) for p in reader.GetGDCMSeriesFileNames(str(path), series_id)]
        metadata = _read_dicom_header(files[0]) if files else {}
        candidates.append(
            DicomSeriesCandidate(
                series_id=series_id,
                source_dir=path,
                files=files,
                first_file_metadata=metadata,
            )
        )
    return candidates


def load_dicom_series(candidate: DicomSeriesCandidate) -> LoadedVolume:
    sitk = _require_sitk()
    reader = sitk.ImageSeriesReader()
    reader.SetFileNames([str(p) for p in candidate.files])
    reader.MetaDataDictionaryArrayUpdateOn()
    reader.LoadPrivateTagsOn()
    image = reader.Execute()

    fp = SeriesFingerprint(
        source_path=candidate.source_dir,
        source_kind="dicom_series",
        series_id=candidate.series_id,
        num_files=len(candidate.files),
        modality=candidate.first_file_metadata.get("Modality") or "MR",
        manufacturer=candidate.first_file_metadata.get("Manufacturer"),
        manufacturer_model_name=candidate.first_file_metadata.get("ManufacturerModelName"),
        magnetic_field_strength_t=candidate.first_file_metadata.get("MagneticFieldStrength"),
        series_description=candidate.first_file_metadata.get("SeriesDescription"),
        sequence_name=candidate.first_file_metadata.get("SequenceName"),
        protocol_name=candidate.first_file_metadata.get("ProtocolName"),
        scanning_sequence=candidate.first_file_metadata.get("ScanningSequence"),
        image_type=candidate.first_file_metadata.get("ImageType"),
        orientation=_orientation_from_direction(image.GetDirection()),
        size=tuple(int(v) for v in image.GetSize()),
        spacing=tuple(float(v) for v in image.GetSpacing()),
        axes_code=sitk.DICOMOrientImageFilter_GetOrientationFromDirectionCosines(image.GetDirection()),
        extra={"source_files": [str(p) for p in candidate.files]},
    )
    return LoadedVolume(image=image, fingerprint=fp, source_files=candidate.files)


def load_nifti(path: str | Path) -> LoadedVolume:
    sitk = _require_sitk()
    path = Path(path)
    if not path.exists():
        raise InputError(f"Input file not found: {path}")

    image = sitk.ReadImage(str(path))
    fp = SeriesFingerprint(
        source_path=path,
        source_kind="nifti",
        series_id=None,
        num_files=1,
        modality="MR",
        series_description=path.name,
        orientation=_orientation_from_direction(image.GetDirection()),
        size=tuple(int(v) for v in image.GetSize()),
        spacing=tuple(float(v) for v in image.GetSpacing()),
        axes_code=sitk.DICOMOrientImageFilter_GetOrientationFromDirectionCosines(image.GetDirection()),
        extra={},
    )
    return LoadedVolume(image=image, fingerprint=fp, source_files=[path])


def discover_input_candidates(path: str | Path) -> List[LoadedVolume]:
    path = Path(path)
    if not path.exists():
        raise InputError(f"Input path does not exist: {path}")

    if path.is_file():
        if path.suffix.lower() in {".nii", ".gz"} or path.name.endswith(".nii.gz"):
            return [load_nifti(path)]
        raise InputError("Single-file input currently supports NIfTI only.")

    # Directory: try DICOM discovery first.
    candidates = discover_dicom_series(path)
    return [load_dicom_series(c) for c in candidates]


def write_image(image: Any, path: str | Path) -> None:
    sitk = _require_sitk()
    sitk.WriteImage(image, str(path), useCompression=True)


def write_json(data: Dict[str, Any], path: str | Path) -> None:
    Path(path).write_text(json.dumps(data, indent=2, sort_keys=True))
